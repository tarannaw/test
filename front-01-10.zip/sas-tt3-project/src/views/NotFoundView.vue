<script setup>

</script>
 
<template>
<div>
<h2 class=" text-red-500">You Page Not Found </h2>
</div>
</template>
 
<style scoped>

</style>