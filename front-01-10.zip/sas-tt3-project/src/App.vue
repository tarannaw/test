<script setup>
// import { getQuestions } from './code/get.js'
import Data from'./components/Announcement.vue'
import Nav from './components/Nav.vue'

</script>

<template>
  <div>
    <RouterView/>
  </div>
</template>

<style scoped></style>




