<script setup>
import Nav from '../components/Nav.vue'
import User from '../components/ShowUser.vue'
</script>
 
<template>
<div>
<User></User>
</div>
</template>
 
<style scoped>

</style>